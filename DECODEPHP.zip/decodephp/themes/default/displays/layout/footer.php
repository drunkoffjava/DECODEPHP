<!-- Footer -->
<footer class="bg-white border-t border-gray-200 mt-12">
    <div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div class="text-center text-gray-500 text-sm">
            &copy; <?= date('Y') ?> DECODE Framework. All rights reserved.
        </div>
    </div>
</footer>
</body>
</html> 