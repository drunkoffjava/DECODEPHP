<?php include __DIR__ . '/header.php'; ?>

<!-- Main Content -->
<main class="main-content">
    <?= $display->content ?? 'No content provided' ?>
</main>

<?php include __DIR__ . '/footer.php'; ?> 